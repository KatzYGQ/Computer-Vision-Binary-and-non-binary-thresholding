#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std;

int main(int argc, char* argv[]) {
    // step 0:
    // inFile open argv[1]
    ifstream inFile(argv[1]);
    
    if (!inFile.is_open()) {
        cout << "Unable to open file" << endl;
        exit(1);
    }

    // thrValue: cast argv[2] from string to integer
    //for this project, threshold value is 43
    int thrValue =atoi(argv[2]);

    // outFile1 open args[3]
    ofstream outFile1(argv[3]);
    if (!outFile1.is_open()) {
        cout << "Unable to open output file 1: " << argv[3] << endl;
        exit(1);
    }

    // outFile2 open args[4]
    ofstream outFile2(argv[4]);
    if (!outFile2.is_open()) {
        cout << "Unable to open output file 2: " << argv[4] << endl;
        exit(1);
    }

    // numRows, numCols, minVal, maxVal read from inFile
    int numRows, numCols, minVal, maxVal;
    inFile >> numRows >> numCols >> minVal >> maxVal;

    // step 1
    // outFile1 output numRows, numCols, 0, 1
    outFile1 << numRows << " " << numCols << " 0 1" << endl;

    // outFile2 output numRows, numCols, 0, maxVal
    outFile2 << numRows << " " << numCols << " 0 " << maxVal << endl;


    int pixelVal;
    int count = 0;
    
    while (inFile >> pixelVal) { //read one integer from inFile
        if (pixelVal >= thrValue) { 
            //binary threshold
            outFile1 << "1 "; //write 1 follows 1 blank

            //non-binary threshold
            outFile2 << pixelVal << " "; //write pixelVal follows by 1 blank
        }
        else {
            outFile1 << "0 "; //write 0 follows by 1 blank
            outFile2 << "0  "; //wtire 0 follows by 2 blank
        }

        count++;

        if (count >= numCols) {
            outFile1 << endl;
            outFile2 << endl;
            count = 0;
        }
    }

    inFile.close();
    outFile1.close();
    outFile2.close();

    return 0;
}
